<?php

	/*
	 Planned usage:
	 	// first run:
	 	$csv = new CSVImport([
			'table' => 'orders',
			'csvFile' => '/path/to/file.csv',
			'updateExistingRecords' => true,
			...
	 	]);
	 	$jobId = $csv->getJobId();
	 	
	 	$ids = $csv->importBatch(); // returns array of IDs of imported records
	 	$errors = $csv->importErrors(); // returns array of import errors  (or empty array if non)
	 	$progress = $csv->progress(); // returns progress stats assoc array
	 	$done = $csv->isDone(); // returns boolean indicating if there is more to import

	 	// later runs
	 	$csv = new CSVImport([
	 		'jobId' => $jobId,
	 		'rowFilterCallback' => function($data) { return true; },
	 		'rowTransformCallback' => function($data) { return $transformedData; }
	 	]);
	 	if($csv->error) // handle error ...

	 	$ids = $csv->importBatch(); // returns array of IDs of imported records
		...

		This class is designed so that it can initiate/continue an import job autonomously
		whenever it's initiated until the job is done .. thus it would keep track of progress
		internally with no need to pass a starting point to it .. only a jobId is all that's
		needed to continue a paused job.
	 */

	class CSVImport {
		const JOBS_TABLE = 'appgini_csv_import_jobs';
		const JOBS_LOG_TABLE = 'appgini_csv_import_jobs_log';
		const OLD_JOBS_AGE = 5; // age in days after which jobs are cleaned up form db
		const MAX_EXECUTION_TIME = 5; // batch processing would respect this time, in seconds
		const CLEAN_CSV_DIR = 'import-csv'; // relative to appDir

		private $config = [
			'table' => '',
			'fieldSeparator' => ',',
			'lineSeparator' => "\n",
			'fieldWrapper' => '"',
			'recordsPerInsert' => 100,
			'updateExistingRecords' => false,
			'rowFilterCallback' => null,
			'rowTransformCallback' => null,
			'csvFile' => '',
			'csvHasHeaderRow' => false,
			'csvMap' => [], // ['csv-column-index-0-based' => 'fieldname', ...]

			// for internal use, can't be set outside class
			// 'cleanCsvFileReady' => boolean indicating if clean CSV file ready for importing to db
			// 'cleanCsvFile' => full path to clean CSV file
			// 'rawIndex' => last read position from csvFile
		];				

		/*
			LIMITATION: if you are running a batch import by passing an jobId,
			you have to redefine rowFilterCallback and rowTransformCallback since
			callbacks can't be serialized for storage :/
		*/
		private $jobId, $memberInfo, $timeElapsed = 0.0, $startTS, $pkAutoInc = [];

		public $error = ''; // on error, would include a string to be used as key to $Translation
		public $logs = []; // array containing detailed logging info

		public function __construct($config = []) {
			$this->memberInfo = getMemberInfo();
			$this->appDir = realpath(dirname(__FILE__) . '/../..');

			// initial setup and cleanup if needed
			$this->setupDirs();
			$this->setupDb();
			$this->cleanupOldJobs();

			// do we have a jobId? This case means we're resuming a long import job
			if(!empty($config['jobId'])) {
				if(!$this->loadJob($config['jobId'])) {
					$this->error = 'Invalid import job';
					return;
				}

				// configure callbacks, as they aren't stored in job config
				array_map(function($key) use ($config) {
					if(!empty($config[$key])) $this->config[$key] = $config[$key];
				}, ['rowFilterCallback', 'rowTransformCallback']);

				return;
			}

			// we are creating a new import job
			// assign provided config to class props
			foreach ($this->config as $key => $value)
				if(!empty($config[$key])) $this->config[$key] = $config[$key];

			// create a jobId that we can refer to later
			$this->saveJob();
		}

		/* if nothing returned, check ->error */
		public function getJobId() {
			return $this->jobId;
		}

		public function importBatch() {
			if(!$this->config['importedCount']) $this->config['importedCount'] = 0;

			// First of all, validate that $this->config includes all the info we need to proceed


			// Then, check that cleanCsvFile is ready, $this->cleanupCSV() should return true;
			if(!$this->cleanupCSV()) {
				// TODO: either there is an error during cleanup,
				// or cleanup is still in progress ....
			}

			// open clean csv file for reading records and importing them to db
			if(!($fpClean = @fopen($this->config['cleanCsvFile'], 'r'))) {
				$this->error = 'error reading file';
				return false;
			}

			// skip already read lines
			if($this->config['cleanIndex'])
				fseek($fpClean, $this->config['cleanIndex']);

			$eo = ['silentErrors' => true];
			$table = '`' . makeSafe($this->config['table']) . '`';
			$numFields = count($this->config['csvMap']);

			while(!feof($fpClean) && !$this->timeUp()) {
				// Starting with (cleanIndex), read up to {recordsPerInsert} lines from {cleanCsvFile}
				$rows = [];

				while(
					!feof($fpClean) &&
					($line = fgetcsv($fpClean, 0, $this->config['fieldSeparator'], $this->config['fieldWrapper'])) !== false &&
					!$this->timeUp() &&
					// if recordsPerInsert == 1, count(rows) will always be 0, and the condition would always
					// be true .. the loop would continue until any of the above conditions is no longer true
					count($rows) < $this->config['recordsPerInsert']
				) {
					// record current position in clean csv
					$this->config['cleanIndex'] = ftell($fpClean);

					// create assoc array $row from csvMap and line
					$row = array_combine($this->config['csvMap'], $line);

					// skip if num columns in read line not same as num fields
					if(count($line) != $numFields) {
						$this->logs[] = "index: {$this->config['cleanIndex']}, error: value count doesn't match field count, action: skipped.";
						$this->saveJob();
						continue;
					}

					// if rowFilterCallback returns false, skip this row
					if(is_callable($this->config['rowFilterCallback']))
						if(!call_user_func_array($this->config['rowFilterCallback'], [$row])) {
							$this->logs[] = "index: {$this->config['cleanIndex']}, status: rowFilterCallback returned false, action: skipped.";
							$this->saveJob();
							continue;
						}

					// if rowTransformCallback is a function, use it to return transformed data
					if(is_callable($this->config['rowTransformCallback'])) {
						$row = call_user_func_array($this->config['rowTransformCallback'], [$row]);
						$line = array_values($row);
					}

					// prepare $line for query
					$line = array_map(function($v) {
						return $v === '' ? 'NULL' :  "'" . makeSafe($v) . "'";
					}, $line);

					// if recordsPerInsert > 1 then do a mass insert after the loop 
					if($this->config['recordsPerInsert'] > 1) {
						$rows[] = '(' . implode(',', $line) . ')';
						continue;
					}

					$this->insertOneRecord($table, $line);
				}
				
				if(!count($rows)) continue;

				$this->saveJob();
				
				// INSERT OR UPDATE?
				$query = $this->config['updateExistingRecords'] ? 'REPLACE ' : 'INSERT IGNORE INTO ' .
						"{$table} " .
						'(`' . implode('`,`', $this->config['csvMap']) . '`) ' .
						"VALUES \n" .
						implode(",\n", $rows);

				$eo['error'] = ''; // to reset previous errors
				if(!sql($query, $eo)) {
					$error = $eo['error'];
					$action = db_affected_rows() ? 'inserted' : 'skipped';
					$this->logs[] = "index: {$this->config['cleanIndex']}, error: {$error}, action: {$action}.";
					$this->saveJob();
					continue;
				}

				$this->config['importedCount'] += db_affected_rows();

				$this->saveJob();
			}
		}

		private function validateConfig($forCleanup = 0, $forImport = 0) {
			if($forCleanup) {
				

				return true;
			}

			if($forImport) {

				return true;
			}
		}

		private function insertOneRecord($table, $fields) {
			// we'll insert a single record here
			// and if it's ok, assign owner as current user
			$query = $this->config['updateExistingRecords'] ? 'REPLACE ' : 'INSERT IGNORE INTO ' .
					"{$table} " .
					'(`' . implode('`,`', $this->config['csvMap']) . '`) ' .
					"VALUES \n" .
					implode(",", $line);

			// on error, log error, save progress, and skip ownership
			$eo = ['silentErrors' => true];
			if(!sql($query, $eo)) {
				$action = db_affected_rows() ? 'inserted' : 'skipped';
				$this->logs[] = "index: {$this->config['cleanIndex']}, error: {$eo['error']}, action: {$action}.";
				$this->saveJob();
				return;
			}

			// if no new insert id, skip ownership
			$insertId = $this->getInsertId($table, $line);
			if($this->config['lastInsertId'] == $insertId || !db_affected_rows()) {
				$action = db_affected_rows() ? 'inserted' : 'skipped';
				$this->logs[] = "index: {$this->config['cleanIndex']}, error: no insert id, action: {$action}.";
				$this->saveJob();
				return;
			}

			// keep record of insert id
			$this->config['lastInsertId'] = $insertId;

			// update importedCount
			$this->config['importedCount'] += 1;

			// assign owner
			if(!set_record_owner($table, $insertId, $this->memberInfo['username'])) {
				$this->logs[] = "index: {$this->config['cleanIndex']}, error: failed to assign owner, action: inserted.";
				$this->saveJob();
				return;
			}

			$this->logs[] = "index: {$this->config['cleanIndex']}, id: {$insertId}, action: inserted.";
			$this->saveJob();
		}

		/* returns boolean indicating if PK of given table is auto-increment, cached for performance */
		private function pkIsAutoIncrement($table) {
			// caching
			if(isset($this->pkAutoInc[$table])) return $this->pkAutoInc[$table];

			// get pk of table
			$pk = getPKFieldName($table);

			// check if it's auto-increment
			$eo = ['silentErrors' => true];
			$res = sql("SHOW COLUMNS FROM `{$table}` WHERE Field='{$pk}' AND Extra LIKE '%auto_increment%'", $eo);
			$this->pkAutoInc[$table] = db_num_rows($res) > 0;

			return $this->pkAutoInc[$table];
		}

		private function getInsertId($table, $values) {
			// if table has auto-inc PK, return result of db_insert_id()
			if($this->pkIsAutoIncrement($table)) return db_insert_id();

			// else, get pk value from given values if possible
			$fields = $this->config['csvMap'];
			$pk = getPKFieldName($table);
			$pkIndex = array_search($pk, $fields);
			if($pkIndex === false) return false; // no pk value given

			return $values[$pkIndex];
		}

		private function validConfig() {
			// some checks to perform
			// if current user not in Admins group, make sure recordsPerInsert is 1
			// and updateExistingRecords is false
			// 
			// only admins can perform mass insert with no ownership and update existing records
			// non-admins can insert if they have insert permission, but inserted records are 
			// assigned to them
		}

		/*
		 	returns true if clean file ready
		 	returns false on error or work in progress
		 	(in case of error, $this->error would include the error string)
		 */
		private function cleanupCSV() {
			/*
			 For efficient importing of CSV files, we need to prepare a clean
			 copy of the CSV file, where there is no header line, nor any blank
			 lines. And where all lines have the exact number of fields to be
			 inserted.

			 A file, as specified in $this->config['cleanCsvFile'] is created.
			 A batch of lines is read sequentially from original CSV file ($this->config['csvFile']).
			 Filterd files are added to a buffer and appended to cleanCsvFile.
			 Progress of clean up is recorded in $this->config['rawIndex'], which stores
			 the index of the last read position from csvFile.
			 The above is repeated till end of csvFile, or MAX_EXECUTION_TIME reached.

			 If after loop, we're done cleaning up all rows, return true, else return false

			 Related configs:
			 csvFile: the full path to the original csv file
			 cleanCsvFile: determined here the first time, then loaded from stored config later
			 				includes path, $this->appDir . '/' . self::CLEAN_CSV_DIR
			 	>>> index of last line read from csvFile should be stored somewhere:
			 	>>> a flag to indicate if cleanCsvFile is ready for importing
			 */

			// if file ready, with all records, quit
			if($this->config['cleanCsvFileReady']) return true;

			// first run? create and open clean file for appending
			if(!$this->config['cleanCsvFile']) {
				if(!($fpClean = $this->newCleanCsvFile())) return false; // file can't be created ... see ->error

			// otherwise open clean file to continue from where we left
			} elseif(!($fpClean = @fopen($this->config['cleanCsvFile'], 'a'))) {
				$this->error = 'clean csv dir error';
				return false;
			}

			// open raw csv file for reading raw records and saving them to clean csv
			if(!($fpRaw = @fopen($this->config['csvFile'], 'r'))) {
				$this->error = 'error reading file';
				return false;
			}

			// skip already read lines
			if($this->config['rawIndex']) {
				fseek($fpRaw, $this->config['rawIndex']);

			// if first read, skip BOM characters if needed, and update rawIndex
			} elseif(!isset($this->config['rawIndex'])) {
				$this->skipBOM($fpRaw);
				$this->config['rawIndex'] = ftell($fpRaw);
				$this->saveJob();
			}

			$numFields = count($this->config['csvMap']);

			while(
				!feof($fpRaw) &&
				($line = fgetcsv($fpRaw, 0, $this->config['fieldSeparator'], $this->config['fieldWrapper'])) !== false &&
				!$this->timeUp()
			) {
				$this->config['rawIndex'] = ftell($fpRaw);

				// skip blanks
				if(!trim(implode('', $line))) continue;

				// skip header if not already
				if($this->config['csvHasHeaderRow'] && !$this->config['headerRowSkipped']) {
					$this->config['headerRowSkipped'] = true;
					continue;
				}

				// if num columns < num fields, append empty columns
				if(count($line) < $numFields)
					$line = array_pad($line, $numFields, '');
				// if num columns > num fields, trim extra ones at the right
				elseif (count($line) > $numFields)
					$line = array_slice($line, 0, $numFields);

				// write line to clean csv
				fputcsv($fpClean, $line, $this->config['fieldSeparator'], $this->config['fieldWrapper']);

				// we should saveJob() here but that would slow down the import :/
			}

			fclose($fpClean);

			if(feof($fpRaw)) $this->config['cleanCsvFileReady'] = true;
			fclose($fpRaw);

			$this->saveJob();

			return true;
		}

		private function newCleanCsvFile() {
			$cleanDir = $this->appDir . '/' . self::CLEAN_CSV_DIR;
			if(!is_dir($cleanDir)) {
				$this->error = 'clean csv dir error';
				return false;
			}

			$this->config['cleanCsvFile'] = $cleanDir . '/' . uniqid('', true);

			if(!($fp = fopen($this->config['cleanCsvFile'], 'w'))) {
				unset($this->config['cleanCsvFile']);
				$this->error = 'clean csv dir error';
				return false;
			}

			return $fp;
		}

		private function saveJob() {
			$error = '';

			// if job already saved, update it
			if($this->jobId) {
				update(
					self::JOBS_TABLE, [
						// fields to update

						// REMEMBER!!
						// rowFilterCallback, rowTransformCallback
						// can't be serialized and MUST be redefined in subsequent runs of this job :/

						'config' => json_encode($this->config),
						'last_update_ts' => time()
					], [
						// where conditions
						'id' => $this->jobId,
						'memberID' => $this->memberInfo['username'] // user can update only their own jobs
					],
					$error
				);

			// new job, so create a jobId then save it
			} else {
				$this->jobId = uniqid('', true);
				insert(
					self::JOBS_TABLE, [
						// fields to update -- see note in update() call above!
						'config' => json_encode($this->config),
						'insert_ts' => time(),
						'id' => $this->jobId,
						'memberID' => $this->memberInfo['username'] // user can update only their own jobs
					],
					$error
				);
			}

			if($error) $this->error = $error;
			return $error ? false : true;
		}

		private function setupDb() {
			$eo = ['silentErrors' => true];

			$tn = self::JOBS_TABLE;
			sql(
				"CREATE TABLE IF NOT EXISTS `{$tn}` (
					`id` VARCHAR(40) NOT NULL,
					`memberID` VARCHAR(100) NOT NULL,
					`config` TEXT,
					`insert_ts` INT,
					`last_update_ts` INT,
					`total` INT DEFAULT 99999999,
					`done` INT DEFAULT 0,
					PRIMARY KEY (`id`),
					INDEX `memberID` (`memberID`)
				) CHARSET " . mysql_charset,
			$eo);

			// TODO
			/*
			$tn = self::JOBS_LOG_TABLE;
			sql(
				"CREATE TABLE IF NOT EXISTS `{$tn}` (
					`id` BIGINT NOT NULL AUTO_INCREMENT,
					`job_id` VARCHAR(40) NOT NULL,
					`ts` INT,
					`details` TEXT,
					PRIMARY KEY (`id`),
					INDEX `job_id` (`job_id`)
				) CHARSET " . mysql_charset,
			$eo);
			*/
		}

		private function setupDirs() {
			$cleanDir = $this->appDir . '/' . self::CLEAN_CSV_DIR;
			if(is_dir($cleanDir)) return;

			@mkdir($cleanDir);
			@touch("{$cleanDir}/index.html");
			@file_put_contents("{$cleanDir}/.htaccess", implode("\n", [
				'<FilesMatch "\.(csv)$">',
				'    Order allow,deny',
				'</FilesMatch>',
			]));
		}

		/* returns jobId if found in db and belongs to current user, falsy value otherwise */
		private function loadJob($jobId) {
			$sjId = makeSafe($jobId);
			$tn = self::JOBS_TABLE;
			$sUsername = makeSafe($this->memberInfo['username']);
			$configJson = sqlValue("SELECT `config` FROM `{$tn}` WHERE `id`='{$sjId}' AND `memberID`='{$sUsername}'");
			if(!$configJson) return false;

			$this->config = json_decode($configJson, true);
			$this->jobId = $jobId;

			return $jobId;
		}

		private function cleanupOldJobs() {
			$eo = ['silentErrors' => true];
			$tn = self::JOBS_TABLE;
			$yesterday = time() - 86400 * self::OLD_JOBS_AGE;
			sql("DELETE FROM `{$tn}` WHERE `insert_ts`<{$yesterday}", $eo);

			// TODO: clean up csv files
		}

		/*
			Use to enforce MAX_EXECUTION_TIME, like so:

		    while(thingNotFinished() && !$this->timeUp()) {
				continueThing();
		    }

		    updateThingProgress();
		*/
		private function timeUp() {
			// startTS recorded yet?
			if(!$this->startTS) $this->startTS = microtime(true);

			$nowTS = microtime(true);
			$this->timeElapsed = $nowTS - $this->startTS;

			return $this->timeElapsed >= self::MAX_EXECUTION_TIME;
		}

		// detect type of UTF encoding and skip the appropriate number of characters
		// returns the detected encoding, or false if unable to detect
		private function skipBOM($fp) {
			$pos = ftell($fp);
			if($pos === false || $pos > 5) return false; // file pointer error, or already passed BOM section
			
			rewind($fp); // back to start
			$f5b = '';
			do { $f5b .= fgetc($fp); } while(strlen($f5b) < 5 && !feof($fp));

			if(strlen($f5b) < 5) return false;

			// for convenience, we'll define $f2b, $f3b and $f4b
			$f2b = $f5b[0] . $f5b[1];
			$f3b = $f2b . $f5b[2];
			$f4b = $f3b . $f5b[3];

			$res = [-5, false];

			// https://en.wikipedia.org/wiki/Byte_order_mark
			if($f3b == '\xEF\xBB\xBF') $res = [-2, 'UTF-8'];

			elseif($f4b == '\xFF\xFE\x00\x00') $res = [-1, 'UTF-32'];
			elseif($f4b == '\x00\x00\xFE\xFF') $res = [-1, 'UTF-32'];

			elseif($f2b == '\xFE\xFF') $res = [-3, 'UTF-16'];
			elseif($f2b == '\xFF\xFE') $res = [-3, 'UTF-16'];

			elseif($f5b == '\x2B\x2F\x76\x38\x2D') $res = [0, 'UTF-7'];

			elseif(in_array($f4b, [
				'\x2B\x2F\x76\x38',
				'\x2B\x2F\x76\x39',
				'\x2B\x2F\x76\x2B',
				'\x2B\x2F\x76\x2F'
			])) $res = [-1, 'UTF-7'];

			elseif($f3b == '\xF7\x64\x4C') $res = [-2, 'UTF-1'];
			
			elseif($f4b == '\xDD\x73\x66\x73') $res = [-1, 'UTF-EBCDIC'];
			elseif($f4b == '\x84\x31\x95\x33') $res = [-1, 'GB-18030'];

			elseif($f3b == '\x00\xFE\xFF') $res = [-2, 'SCSU'];
			
			elseif($f3b == '\xFB\xEE\x28') $res = [-2, 'BOCU-1'];

			fseek($fp, $res[0], SEEK_CUR);
			return $res[1];
		}
	}