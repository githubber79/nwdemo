<?php

header('Content-Type: text/html; charset=UTF-8');
@ini_set('auto_detect_line_endings', true);
$t0 = microtime(true);

ob_start();

$files = [
/*
	'C:\\Users\\bigprof\\Downloads\\test-tab-dos.txt',
	'C:\\Users\\bigprof\\Downloads\\test-tab-mac.txt',
	'C:\\Users\\bigprof\\Downloads\\test-tab.txt',
	'C:\\Users\\bigprof\\Downloads\\NZHEC-codes.csv',
	'C:\\Users\\bigprof\\Downloads\\test-mac.csv',
	'C:\\Users\\bigprof\\Downloads\\test-dos.csv',
	'C:\\Users\\bigprof\\Downloads\\test-default.csv',
	'C:\\Users\\bigprof\\Downloads\\orders-20200414-210030.csv',
	'C:\\Users\\bigprof\\Downloads\\contacts.csv',
	'C:\\Users\\bigprof\\Downloads\\test-unicode-blanks.txt',
	'C:\\Users\\bigprof\\Downloads\\test-unicode.txt',
	'C:\\Users\\bigprof\\Downloads\\covid-19\\time_series_covid19_confirmed_global_narrow.csv',
	'C:\\Users\\bigprof\\Downloads\\CCTXNHistoryUX320-09-2018.csv',
	'C:\\Users\\bigprof\\Downloads\\msft.csv',
	'C:\\Users\\bigprof\\Downloads\\170529150011_group_8dc9cee6_active.csv',
	'C:\\Users\\bigprof\\Downloads\\AppGini-Desktop-Oders_2011-01-01_2017-02-15.csv',
	'C:\\Users\\bigprof\\Downloads\\expediente (1).csv',
*/
	'C:\\Users\\bigprof\\Downloads\\shippers.csv',
	'C:\\Users\\bigprof\\Downloads\\employees.csv',
];



foreach($files as $file) {
	$sep = preg_match('/-(unicode|tab)/', $file) ? "\t" : ',';
	$bytesRead = 0;

	$fp = fopen($file, 'r');

	// detect BOM
	$f3b = fgetc($fp) . fgetc($fp) . fgetc($fp);
	if(!preg_match('/[\x00-\x1F\x80-\xFF]/', $f3b)) {
		rewind($fp);
		$f3b = '';
	} else {
		$bytesRead = 2;
		fseek($fp, -1, SEEK_CUR);
	}

	echo '<h1>' . basename($file) . '</h1>';
	echo "Separator: $sep (" . ord($sep) . ')<br>';
	echo 'BOM? ' . ($f3b ? ord($f3b[0]) . ' ' . ord($f3b[0]) . ' ' . ord($f3b[0]) : 'NONE') . '<br>';
	echo "ftell at start: " . ftell($fp) . ', bytesRead: ' . $bytesRead . '<br>';

	echo '<div style="border: solid 1px #ddd; margin: auto 10%; width: 80%; overflow-x: auto;">';
	echo '<table cellspacing="0" cellpadding="5" border="1" style="width: 100%;">';

	$lines = 0;
	$t1 = microtime(true);
	while(
		!feof($fp) && 
		($line = fgetcsv($fp, 0, $sep, '"')) !== false &&
		($t1 - $t0) < 2.0
	) {
		// in case 1st field is still enclosed with wrapper (happens in files with BOM),
		// we should manually clean it up ...
		
		if(!$lines)
			$line[0] = preg_replace('/[\x00-\x1F\x80-\xFF]?"(.*?)"/', '$1', trim($line[0]));

		// skip blank lines
		$lineBlank = (trim(implode('', $line)) === '');

		// you might need this sometimes so add it as an option ...
		// $line = array_map('utf8_encode', $line);

		if(!$lineBlank) $lines++;

		// this won't work correctly in case of values enclosed with wrappers
		// we have to trust ftell instead ...
		// probably we won't need to seek back 2 bytes either ...
		// $bytesRead += strlen(implode($sep, $line));

		// back 2 bytes and read those 2 bytes
		fseek($fp, -2, SEEK_CUR);
		$eol = fgetc($fp) . fgetc($fp);

		// add EOL to bytesRead
		// $bytesRead += ($eol == "\r\n" ? 2 : 1);
		
		$bytesRead = ftell($fp);

		if(!$lineBlank) {
			echo "<tr><td>{$lines}</td>";
			echo '<td>' . implode('</td><td>' , $line) . '</td>';
			echo '<td>Detected encoding: ' . mb_detect_encoding($line[0], 'UTF-8') . '</td>';
			echo "<td>ftell now: " . ftell($fp) . ', bytesRead: ' . $bytesRead . ', Last 2 bytes: ' . ord($eol[0]) . ' ' . ord($eol[1]) . '</td>';
		}


		// simulate resuming file reading
		fseek($fp, $bytesRead);

		$t1 = microtime(true);

		if(!$lineBlank) {
			echo '<td>' . round($t1 - $t0, 3) . '</td>';
			echo '</tr>';
		}
	}

	echo '</table></div>';
	echo "Non-blank lines read: $lines<br>";
	if(feof($fp)) echo 'EOF';
	fclose($fp);

	echo '<hr>';
}

$out = ob_get_clean();

echo md5($out) . '<br>';
echo $out;