How to apply the patch in patch-makesafe.zip?
---------------------------------------------

1. Extract patch-makesafe.php and copy to the hooks folder inside your AppGini app folder.

2. In your web browser, navigate to {your-app-url}/hooks/patch-makesafe.php
   (replacing {your-app-url} with your actual app URL).

3. To check if the patch worked successfully or not, navigate to {your-app-url}/hooks/patch-makesafe.php?patch-check=1

The patch is designed to work even if you regenerate your app later on. So, it's a run-once-and-forget fix.